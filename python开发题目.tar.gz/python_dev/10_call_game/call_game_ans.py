#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np

class Solution:
    def LastRemaining_Solution(self,var):
        n = var[0] ; m = var[1]
        # write code here
        if n == 0 or m<=0:
            return -1
        new = 1
        old = None
        for i in range(2,n+1):
            old = (new + m-1)%i+1
            new = old
        return old-1

if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = []
     for m in range(1,11):
          contents.append((m+np.random.random_integers(100),m))
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          sol = Solution()
          res_pds.append(sol.LastRemaining_Solution(contents[i]))
     assert len(res_pds) == 10
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv