#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
    def main(self,n):
        pass

if __name__=="__main__":
    sol = Solution()
    print(sol.main(2))
