#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
    def main(self, number):
        res = [0,1,2]
        while len(res) <= number:
            res.append(res[-1] + res[-2])
        return res[number]

