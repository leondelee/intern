#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np

import math
class Solution():
    def damge(self, a1, b1, a2, b2, r):
         dis = math.sqrt((a1-a2)**2 + (b1-b2)**2)
         if dis <= r:
              flag = 1
         else:
              flag = 0
         return flag
    def total_damge(self,var):
         r = var[0] ; x1 = var[1] ; y1 = var[2] ; x2 = var[3] ; y2 = var[4]
         x3 = var[5] ; y3 = var[6] ; x0 = var[7] ; y0 = var[8]
         dam = 0
         dam = dam + self.damge(x1,y1,x0,y0,r)
         dam = dam + self.damge(x2,y2,x0,y0,r)
         dam = dam + self.damge(x3,y3,x0,y0,r)
         return dam

if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = []
     contents = [(1,2,3,4,5,6,7,8,9),
                 (2,2,3,4,5,6,7,8,9),
                 (3,2,3,4,5,6,7,8,9),
                 (4,2,3,4,5,6,7,5,5),
                 (4,2,3,5,6,7,0,5,4),
                 (5,2,3,6,4,8,0,3,5),
                 (4,2,4,6,3,7,9,4,6),
                 (10,2,3,5,7,12,4,4,8),
                 (3,2,5,7,4,5,7,7,9),
                 (6,4,5,8,9,2,5,0,4)]
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          sol = Solution()
          res_pds.append(sol.total_damge(contents[i]))
     assert len(res_pds) == 10
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv