#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
    def main(self,r,x1,y1,x2,y2,x3,y3,x0,y0):
        pass

if __name__=="__main__":
    sol = Solution()
    print(sol.main(1,1,1,2,2,3,3,1,2))
