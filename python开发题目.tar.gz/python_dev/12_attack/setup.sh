#! /bin/bash

touch 配置文件.txt
echo "请输入题目名称"
read name
echo "请输入知识点"
read point
echo "请输入难度"
read diffi
echo "请输入题目描述"
read desc
echo "题目名称：${name}
知识点：${point}
难度：${diffi}
问题描述(需求):${desc}">>配置文件.txt

touch main.py
echo "#!/usr/bin/env python3
# -*- coding: utf-8 -*-">>main.py

touch test.py
echo "#!/usr/bin/env python3
# -*- coding: utf-8 -*-">>test.py



