#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import math
class Solution():
    def damge(self, a1, b1, a2, b2, r):
         dis = math.sqrt((a1-a2)**2 + (b1-b2)**2)
         if dis <= r:
              flag = 1
         else:
              flag = 0
         return flag
    def total_damge(self,r,x1,y1,x2,y2,x3,y3,x0,y0):
         dam = 0
         dam = dam + self.damge(x1,y1,x0,y0,r)
         dam = dam + self.damge(x2,y2,x0,y0,r)
         dam = dam + self.damge(x3,y3,x0,y0,r)
         return dam
if __name__=="__main__":
    sol = Solution()
    print(sol.total_damge(1,1,1,2,2,3,3,1,2)) #结果为2
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
