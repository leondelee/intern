#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def unlucky(year):
    res = []
    return res
