#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import datetime
def unlucky(year):
     res = " ".join(map(str, filter(lambda c: str(datetime.datetime(year, c, 13).strftime("%w")) == "5", range(1, 13))))
     if res:
          flag = []
          for ele in res.split(' '):
               flag.append(int(ele))
     else:
          flag = 'Lucky'
     return flag
if __name__=="__main__":
    print(unlucky(2000))   #结果为[10]
