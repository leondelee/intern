#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
    def main(self,x,y):
        pass

if __name__=="__main__":
    sol = Solution()
    print(sol.main(2,2))

