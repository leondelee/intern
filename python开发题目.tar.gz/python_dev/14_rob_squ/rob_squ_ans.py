#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np

class Solution:
     def countWays(self, var):
          x = var[0]
          y = var[1]
          if x == 1 or y == 1: return 1
          dp = [[1 for i in range(y)] for j in range(x)]
          for i in range(1, x):
              for j in range(1, y):
                  dp[i][j] = dp[i - 1][j] + dp[i][j - 1]
          return dp[-1][-1]

if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = []
     for m in range(1,11):
          contents.append((np.random.random_integers(m),12-m))
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          sol = Solution()
          res_pds.append(sol.countWays(contents[i]))
     assert len(res_pds) == 10
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv