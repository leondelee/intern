#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np

class Solution:
     def main(self,var):
          n = len(var[1])
          w = var[0]
          v = var[1]
          global ans
          if sum(v)<=w:
               flag = 2**(len(v))
          else:
               v.sort()
               self.dfs(0,0,v,w,n)
               flag = ans
          return flag
     def dfs(self,su,loc,v,w,n):
          global ans
          if su>w:
               return
          if su<=w:
               ans += 1
          for i in range(loc,n):
               self.dfs(su+v[i],i+1,v,w,n)
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = []
     for m in range(1,11):
          contents.append((m+5,np.random.randint(low=1,high=5,size=(np.random.random_integers(low=1,high=10)))))
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          ans = 0
          sol = Solution()
          res_pds.append(sol.main(contents[i]))
     assert len(res_pds) == 10
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv