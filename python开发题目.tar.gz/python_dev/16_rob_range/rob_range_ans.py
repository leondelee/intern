#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np

class Solution:
    def main(self, var):
        threshold = var[0]
        rows = var[1]
        cols = var[2]
        self.row, self.col = rows, cols
        self.dict = set()
        self.search(threshold, 0, 0)
        return len(self.dict)
 
    def judge(self, threshold, i, j):
        return sum(map(int, list(str(i)))) + sum(map(int, list(str(j)))) <= threshold
 
    def search(self, threshold, i, j):
        if not self.judge(threshold, i, j) or (i, j) in self.dict:
            return
        self.dict.add((i, j))
        if i != self.row - 1:
            self.search(threshold, i + 1, j)
        if j != self.col - 1:
            self.search(threshold, i, j + 1)
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = [(10,50,50),(12,50,50),(14,50,50),
                 (11,50,60),(13,60,50),(15,60,60),
                 (16,60,60),(18,60,70),(20,70,60),(17,70,70)]
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          sol = Solution()
          res_pds.append(sol.main(contents[i]))
     assert len(res_pds) == 10
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv