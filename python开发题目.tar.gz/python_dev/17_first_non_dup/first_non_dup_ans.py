#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np

class Solution:
     def main(self, s):
          if s == "":
               return -1
          else:
               counts = {}
               for i in s:
                    if i not in counts:
                         counts[i] = 1
                    else:
                         counts[i] += 1
          flag = -1
          for index,i in enumerate(s):
               if counts[i] == 1:
                    flag = index
                    break
          return flag
               
                    
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = ['abcabc','abcdabc','jmappelle','leon','neuralnetwork',
                 'liliangwei','wangyanhao','shenzhexiao','lichenwei','ankcukauh']
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          sol = Solution()
          res_pds.append(sol.main(contents[i]))
     assert len(res_pds) == 10
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv