#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
     def main(self, s):
          if s == "":
               return -1
          else:
               counts = {}
               for i in s:
                    if i not in counts:
                         counts[i] = 1
                    else:
                         counts[i] += 1
          flag = -1
          for index,i in enumerate(s):
               if counts[i] == 1:
                    flag = index
                    break
          return flag
               
                    
if __name__=="__main__":
    sol = Solution()
    print(sol.main('abcdabc'))   #3
