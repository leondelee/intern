#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def main(W, Y, x, N):
    pass

if __name__=="__main__":
    print(main(5,5,0.2,3))   
