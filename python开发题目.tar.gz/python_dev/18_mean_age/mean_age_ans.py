#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
import math
def average(W, Y, x, N):
    N = int(N)
    for i in range(0, N):
        # (新入职员工年龄总和 + 老员工年龄增长一年后总和) / 公司总人数
        Y = ((21 * (W * x)) + (((Y + 1) * W) * (1 - x))) / W
    # 向上取整
    Y = math.ceil(Y)
    return int(Y)
def main(var):
    try:
         W = var[0] ; Y = var[1] ; x = var[2] ; N = var[3]
         return average(W, Y, x, N)
    except:
         pass
               
                    
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = [(5,5,0.2,3),(50,20,0.2,3),(50,25,0.2,3),(100,27,0.2,3),(1000,28,0.2,3),
                 (5,5,0.5,3),(50,20,0.5,3),(50,25,0.3,5),(50,27,0.5,5),(50,28,0.4,6)]
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          #sol = Solution()
          res_pds.append(main(contents[i]))
     assert len(res_pds) == 10
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv