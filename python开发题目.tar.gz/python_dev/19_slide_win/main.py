#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
    def main(self, n_list, k):
        pass

if __name__=="__main__":
    sol = Solution()
    print(sol.main([2,3,4,2,6,2,5,1],3))   
