# -*- coding: utf-8 -*-
import os
def ip_valid(s):
    assert type(s)==str
    a = s.split('.')
    if len(a) != 4:
        return False
    for x in a:
        if not x.isdigit() or x.startswith('0'):
            return False
        i = int(x)
        if i < 0 or i > 255:
            return False
    return True

if __name__=="__main__":
     inp = 'input.txt'
     res = 'res.txt'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     ips = ['12.255.56.1','202.56.120.230','12.56.113.3','','abc.def.ghi.jkl','123.456.789.0','12.34.56.-1','123.045.067.089','12.34.56','12.34.56 .1']
     for ip in ips:
          inp_file = open(inp,'a+')
          inp_file.write(ip+'\n')
          out_file = open(res,'a+')
          out_file.write(str(ip_valid(ip))+'\n')
     inp_file.close()
     out_file.close()