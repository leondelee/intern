def ip(s):
    '''
    请在这里补全判断IPv4合法性的函数
    '''
    flag = False
    return flag 
