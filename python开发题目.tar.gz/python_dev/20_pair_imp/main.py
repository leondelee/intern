#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def mysort(n_list):
     pass
if __name__=="__main__":
    print(mysort([97,58,11,45,19]))  
