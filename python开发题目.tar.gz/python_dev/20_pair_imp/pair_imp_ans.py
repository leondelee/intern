#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
import math
def mysort(n_list):
     return sorted(n_list,key=lambda c:c%2,reverse=True)
                    
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = []
     for i in range(10):
          contents.append(np.random.randint(100,size=(i+5)).tolist())
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          #sol = Solution()
          res_pds.append(mysort(contents[i]))
     assert len(res_pds) == 10
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv