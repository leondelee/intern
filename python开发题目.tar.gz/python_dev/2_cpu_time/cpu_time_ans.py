#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 13:26:18 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
def cpu_time(n_list):
     arr=[int(i) for i in n_list]
     h=set(arr)  
     for i in arr:   
         for j in list(h):
             h.add(i+j)     
     h=[i for i in h if i>=sum(arr)/2]
     return min(h)
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     # generating 10 suits of data
     ns = [i for i in range(2,12)]
     n_lists=[]
     value_range = range(1,5)
     for list_size in range(2,12):
          n_lists.append(list(1024*np.random.choice([1,5],list_size)))
     contents = n_lists  
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pd = []
     for content in contents:
          res_pd.append(cpu_time(content))
     pd.DataFrame(res_pd).to_csv(res,header=None,index=False) #output to csv