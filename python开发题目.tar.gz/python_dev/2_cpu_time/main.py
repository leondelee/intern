#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def cpu_time(n_list):
    min_time = 0
    #please write your code here
    
    return min_time
