#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 13:26:18 2018

@author: llw
"""
def cpu_time(n_list):
     arr=[int(i) for i in n_list]
     h=set(arr)  
     for i in arr:   
         for j in list(h):
             h.add(i+j)     
     h=[i for i in h if i>=sum(arr)/2]
     return min(h)
