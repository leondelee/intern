#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:01 2018

@author: llw
"""

def change_time(list):
     pass