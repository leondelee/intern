#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
def change_time(s):
     s = [i for i in s]
     loctionsB = loctionsG = icountB = icountG = 0
     for i in range (len(s)):
          if s[i] == 'B':
               icountB += i - loctionsB
               loctionsB += 1
          else:
               icountG += i - loctionsG
               loctionsG += 1
     return min(icountB,icountG)
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = ['BBG','BBGB','BGBGB','BGGBGB','BGBBGBG','GGBGBBGG','GBGBGBGBG','GGBGGBGBBG','BBBGGBGGBGGBGBGB','BGBBGGGBGBGBGBBGBGG']
    
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pd = []
     for content in contents:
          res_pd.append(change_time(content))
     pd.DataFrame(res_pd).to_csv(res,header=None,index=False) #output to csv