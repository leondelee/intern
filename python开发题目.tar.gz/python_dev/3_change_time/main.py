#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def change_time(s):
#请在这里写你的代码
    time = 0
    return time
