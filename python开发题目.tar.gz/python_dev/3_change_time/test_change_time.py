#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:41:01 2018

@author: llw
"""
import unittest
import change_time_ans as tested

s = 'GGBBG'

class TestChangeTime(unittest.TestCase):
     def test_change_time(self):
          try:
               self.assertEqual(tested.change_time(s),2)
               print('Passed')
          except:
               print('Failed')
               
if __name__=='__main__':
     unittest.main()