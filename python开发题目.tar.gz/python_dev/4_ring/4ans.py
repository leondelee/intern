#!/usr/bin/python
# coding:utf-8
def ring(times, c):
    # No.1
    # 开始写代码，请在这里补全代码
    l = 0
    length = len(c)
    while l < times:
        temp = []
        for m in c:
            temp.append(m)
        first = temp[0]
        del temp[0]
        temp.append(first)
        o = 0
        while o < length:
            s = temp[o] + c[o]
            if s >= 100:
                s = int(s) % 100
            c[o] = s
            o += 1
        l += 1
    return c
