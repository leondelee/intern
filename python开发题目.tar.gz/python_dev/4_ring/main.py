#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def ring(times,c):
    res = []
    '''
    times:发生魔力的次数
    c:手环的初始状态
    请在这里写你的代码
    '''
    return res
    
	    

