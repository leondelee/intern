#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
def ring(var):
     times = var[0]
     length = len(var[1])
     c = var[1]
     l = 0
     while l < times:
          temp = []
          for m in c:
               temp.append(m)
          first = temp[0]
          del temp[0]
          temp.append(first)
          o = 0
          while o < length:
               s = temp[o] + c[o]
               if s >= 100:
                    s = int(s) % 100
                    
               c[o] = s
               o += 1
          l += 1
     return c
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     temp_list = list(range(10))
     for i in range(10):
          temp_list[i] = [1,2,3,4]
     contents = list(zip(list(range(1,11)),temp_list))
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          res_pds.append(ring(contents[i]))
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv