#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
def ring(times,c):
     l = 0
     while l < times:
          temp = []
          for m in c:
               temp.append(m)
          first = temp[0]
          del temp[0]
          temp.append(first)
          o = 0
          while o < length:
               s = temp[o] + c[o]
               if s >= 100:
                    s = int(s) % 100
                    
               c[o] = s
               o += 1
          l += 1
     return c
