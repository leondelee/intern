#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
def ensemble(wxyz):
     
     w = wxyz[0]
     
     x = wxyz[1]
     
     y = wxyz[2]
     
     z = wxyz[3]
     
     p = []
     
     q = []
     
     for i in range(w, x+1, 1):
     
         p.append(i)
     
     for j in range(y, z+1, 1):
     
         q.append(j)
     
     result = []
     
     for i in range(0, len(p), 1):
     
         for j in range(0, len(q), 1):
     
             data = float(p[i]) / q[j]
     
             result.append(data)
     
     end = set(result)
     
     return len(end)
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = [[1,2,3,4],[1,2,3,5],[1,2,3,6],[1,2,3,7],[1,2,3,8],
                 [1,3,3,5],[1,4,3,5],[1,5,3,5],[1,6,3,5],[1,7,2,5]]
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          res_pds.append(ensemble(contents[i]))
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv