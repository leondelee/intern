#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def ensemble(wxyz):
    w = wxyz[0]     
    x = wxyz[1]     
    y = wxyz[2] 
    z = wxyz[3]
    length = 0
    #请在这里写你的代码
    return length
