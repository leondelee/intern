#!/usr/bin/python
# coding:utf-8
def sr(expression):
    expression = list(expression)
    res = int(expression[0])
    # No.1
    # 开始写代码，请在这里补全代码
    for i in range(len(expression)- 2):
     
        if expression[i+1] == '+' :
     
            res = res + int(expression[i+2])
     
        if expression[i+1] == '-' :
     
            res = res - int(expression[i+2])
     
        if expression[i+1] == '*' :
     
            res = res * int(expression[i+2])
     
        i= i + 2
     
    return res
