#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def sr(expression):
    res = 0
    #请在这里写你的代码
    return res
    
