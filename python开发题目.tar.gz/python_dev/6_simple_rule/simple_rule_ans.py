#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
def sr(var):
     
     
     expression = var
     
     expression = list(expression)
     
     res = int(expression[0])
     
     for i in range(len(expression)- 2):
     
         if expression[i+1] == '+' :
     
             res = res + int(expression[i+2])
     
         if expression[i+1] == '-' :
     
             res = res - int(expression[i+2])
     
         if expression[i+1] == '*' :
     
             res = res * int(expression[i+2])
     
         i= i + 2
     
     return res
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = ['1*2*3','1-2-3','5*6-8','4*6*7-6-8','6+5*7','6-3*4','7*9*5-4+6',
                 '2-1*5=4','9-4+4*2+1','7*6+7*5-9*0']
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          res_pds.append(sr(contents[i]))
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv