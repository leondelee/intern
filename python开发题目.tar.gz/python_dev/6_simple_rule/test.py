#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def sr(expression):    
     expression = list(expression)
     
     res = int(expression[0])
     
     for i in range(len(expression)- 2):
     
         if expression[i+1] == '+' :
     
             res = res + int(expression[i+2])
     
         if expression[i+1] == '-' :
     
             res = res - int(expression[i+2])
     
         if expression[i+1] == '*' :
     
             res = res * int(expression[i+2])
     
         i= i + 2
     
     return res
