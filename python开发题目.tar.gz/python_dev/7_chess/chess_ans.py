#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
def chess(var):
     num = var.shape[0]
     arr = var
     result = []
     for i in range(num):
          B_count =[1]
          for j in range(0,num-1):
               if arr[j][i] == arr[j+1][i]:
                    B_count[-1]+=1
               else:
                    B_count.append(1)
          result.append(max(B_count))
     return max(result)
if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = []
     for i in range(2,12):
          contents.append(np.random.randint(2,size=(i,i)))
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          res_pds.append(chess(contents[i]))
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv