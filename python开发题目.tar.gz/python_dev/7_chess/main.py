#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def chess(arr):
     res = 0
     return res
