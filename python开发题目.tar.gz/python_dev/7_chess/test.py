#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def chess(arr):
     num = len(var)
     result = []
     for i in range(num):
          B_count =[1]
          for j in range(0,num-1):
               if arr[j][i] == arr[j+1][i]:
                    B_count[-1]+=1
               else:
                    B_count.append(1)
          result.append(max(B_count))
     return max(result)
