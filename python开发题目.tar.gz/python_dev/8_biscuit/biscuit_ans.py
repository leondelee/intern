#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 14:38:44 2018

@author: llw
"""
import os
import pandas as pd
import numpy as np
def bis(k,n):
     remainders = [1] + [0] * (n - 1)
     for i, s in enumerate(k):
          temp = [0] * n
          if s != 'X':
               s = int(s)
               for j in range(n):
                    temp[(j*10+s) % n] += remainders[j]
          else:
               for s in range(10):
                    for j in range(n):
                         temp[(j*10+s) % n] += remainders[j]
          remainders = temp

     return remainders[0]

if __name__=="__main__":
     inp = 'input.csv'
     res = 'res.csv'
     for name in [inp,res]:
          if os.path.exists(name):
               os.remove(name)
     
     # generating 10 suits of data
     contents = [('99X',3),('12X3X',4),('1X1',3),('X21',3),('45X12',4),
                 ('78X5',3),('56X9',3),('2X6X',7),('3X9X7X',11),('2X3X4X',5)]
     assert len(contents) == 10
     # output
     pd.DataFrame(contents).to_csv(inp,header=None,index=False) #input to csv
     res_pds = []
     for i in range(10):
          res_pds.append(bis(contents[i]))
     pd.DataFrame(res_pds).to_csv(res,header=None,index=False) #output to csv
