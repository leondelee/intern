#! /bin/bash
echo -e "a\nb c"

