#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def bis(k,n):
    res = 0
    return res
