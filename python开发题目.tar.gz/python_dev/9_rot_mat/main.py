#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
    def main(self,mat):
        pass

if __name__=="__main__":
    sol = Solution()
    print(sol.main([[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]]))
    
