#!/usr/bin/python
#coding:utf-8
def ip(s):
    #No.1 
    #开始写代码，请在这里补全判断IPv4合法性的函数
    assert type(s)==str
    a = s.split('.')
    if len(a) != 4:
        return False
    for x in a:
        if not x.isdigit() or x.startswith('0'):
            return False
        i = int(x)
        if i < 0 or i > 255:
            return False
    return True
