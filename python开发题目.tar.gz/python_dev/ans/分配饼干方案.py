#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def bis(k,n):
    remainders = [1] + [0] * (n - 1)
    for i, s in enumerate(k):
         temp = [0] * n
         if s != 'X':
              s = int(s)
              for j in range(n):
                   temp[(j*10+s) % n] += remainders[j]
         else:
              for s in range(10):
                   for j in range(n):
                        temp[(j*10+s) % n] += remainders[j]
         remainders = temp

    return remainders[0]
