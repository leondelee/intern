#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import math
def average(W, Y, x, N):
    N = int(N)
    for i in range(0, N):
        # (新入职员工年龄总和 + 老员工年龄增长一年后总和) / 公司总人数
        Y = ((21 * (W * x)) + (((Y + 1) * W) * (1 - x))) / W
    # 向上取整
    Y = math.ceil(Y)
    return int(Y)
def main(W, Y, x, N):
    try:
         return average(W, Y, x, N)
    except:
         pass
