#! /bin/bash
echo "input number"
read num
num = ${num}
echo "input name"
read name
name = ${name}
mkdir ${num}_${name}
cd ${num}_${name}
touch ${name}_ans.py
touch qdisc
echo "1.问题描述：
2.输入描述：
3.输出描述：
4.输入示例：
5.输出示例:">>qdisc


