#!/usr/bin/python
#coding:utf-8
def cpu_time(n_list):
    
    #No.1 
    #开始写代码，请在这里补全代码
    arr=[int(i) for i in n_list]
    h=set(arr)  
    for i in arr:   
        for j in list(h):
            h.add(i+j)     
    h=[i for i in h if i>=sum(arr)/2]
    return min(h)
