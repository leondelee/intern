#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
    def LastRemaining_Solution(self,m,n):
        # write code here
        if n == 0 or m<=0:
            return -1
        new = 1
        old = None
        for i in range(2,n+1):
            old = (new + m-1)%i+1
            new = old
        return old-1
