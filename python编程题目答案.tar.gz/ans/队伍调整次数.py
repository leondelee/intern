#!/usr/bin/python
# coding:utf-8
def change_time(s):
    # No.1
    # 开始写代码，请在这里补全代码
    s = [i for i in s]
    loctionsB = loctionsG = icountB = icountG = 0
    for i in range (len(s)):
        if s[i] == 'B':
	        icountB += i - loctionsB
	        loctionsB += 1
        else:
            icountG += i - loctionsG
            loctionsG += 1
    return min(icountB,icountG)
    # end_code
