#!/usr/bin/python
# coding:utf-8
def ensemble(wxyz):
    w = wxyz[0]
    x = wxyz[1]
    y = wxyz[2]
    z = wxyz[3]
    # No.1
    # 开始写代码，请在这里补全代码
    p = []
    q = []
    for i in range(w, x+1, 1):
     
        p.append(i)
     
    for j in range(y, z+1, 1):
     
        q.append(j)
     
    result = []
     
    for i in range(0, len(p), 1):
     
        for j in range(0, len(q), 1):
     
            data = float(p[i]) / q[j]
     
            result.append(data)
     
    end = set(result)
     
    return len(end)
