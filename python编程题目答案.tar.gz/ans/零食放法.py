#!/usr/bin/env python3
# -*- coding: utf-8 -*-
class Solution:
    def main(self,n,w,v): 
        global ans
        if sum(v)<=w:
             flag = 2**(len(v))
        else:
            v.sort()
            self.dfs(0,0,v,w,n)
            flag = ans
        return flag
    def dfs(self,su,loc,v,w,n):
        global ans
        if su>w:
            return
        if su<=w:
            ans += 1
        for i in range(loc,n):
            self.dfs(su+v[i],i+1,v,w,n)	
