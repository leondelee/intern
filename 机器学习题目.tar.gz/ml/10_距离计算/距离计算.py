#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
P0 = np.array([[0,0]])
P1 = np.array([[0,1]])
P2  = np.array([[0,1/2]])

def main(P0, P1, p):
    T = P1 - P0
    L = (T ** 2).sum(axis=1)
    U = -((P0[:, 0] - p[:, 0]) * T[:, 0] + (P0[:, 1] - p[:, 1]) * T[:, 1]) / L
    U = U.reshape(len(U), 1)
    D = P0 + U * T - p
    return np.sqrt((D ** 2).sum(axis=1))


if __name__=='__main__':
    print(main(P0,P1,P2))

