#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import sklearn
from sklearn.datasets import fetch_20newsgroups as dataset
raw_data = dataset(subset='all')

data = raw_data.data   #样本
label = raw_data.target#标签

def main():
    #注意你需要使用sklearn.feature_extraction.text.CountVectorizer
    return

if __name__=='__main__':
    model = main()
    test_data = sklearn.feature_extraction.text.CountVectorizer().fit_transform(data)[0]
    print(model.predict(test_data))

