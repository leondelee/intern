#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import sklearn
from sklearn.datasets import fetch_20newsgroups as dataset
raw_data = dataset(subset='all')
data = raw_data.data
label = raw_data.target

def main():
    from sklearn.cross_validation import train_test_split 
    from sklearn.feature_extraction.text import CountVectorizer
    from sklearn.naive_bayes import MultinomialNB
    #词向量
    vec = CountVectorizer()
    my_data = vec.fit_transform(data)
    #数据集分割
    xtrain,xtest,ytrain,ytest = train_test_split(my_data,label,
                                                 test_size=0.25)
    #训练
    model = MultinomialNB()
    model.fit(xtrain,ytrain)
    #预测
    pre = model.predict(xtest)
    print('准确率=',sum(pre==ytest)/ytest.shape[0])
    return model

if __name__=='__main__':
    model = main()
    test_data = sklearn.feature_extraction.text.CountVectorizer().fit_transform(data)[0]
    print(model.predict(test_data))

