#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_boston as dataset
from sklearn.cross_validation import train_test_split 
from sklearn.preprocessing import StandardScaler

raw_data = dataset()
data = raw_data.data
label = raw_data.target
xtrain,xtest,ytrain,ytest = train_test_split(data,label,
                                             test_size=0.25,random_state=33)
def main():
    [r2,mse,mae] = [0,0,0]
    return [r2,mse,mae]
if __name__=='__main__':
    print(main())     
