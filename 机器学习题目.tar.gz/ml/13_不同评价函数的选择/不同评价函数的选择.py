#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_boston as dataset
from sklearn.cross_validation import train_test_split 
from sklearn.preprocessing import StandardScaler

raw_data = dataset()
data = raw_data.data
label = raw_data.target
xtrain,xtest,ytrain,ytest = train_test_split(data,label,
                                             test_size=0.25,random_state=33)


def main():
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import r2_score,mean_squared_error,mean_absolute_error
    lr = LinearRegression() 
    lr.fit(xtrain,ytrain) 
    pre_lr = lr.predict(xtest) 
    return [r2_score(ytest,pre_lr),mean_squared_error(ytest,pre_lr),mean_absolute_error(ytest,pre_lr)]
    
if __name__=='__main__':
    print(main())      #[0.6763403830998693, 25.096985692067783, 3.5261239963985447]

