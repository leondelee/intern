#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_digits as dataset
from sklearn.cross_validation import train_test_split 

raw_data = dataset()
data = raw_data.data
label = raw_data.target

def main():
    return 

