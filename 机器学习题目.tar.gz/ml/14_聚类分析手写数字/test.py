#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
from sklearn.datasets import load_digits as dataset
from sklearn.cross_validation import train_test_split 

raw_data = dataset()
data = raw_data.data
label = raw_data.target

def main():
				import matplotlib.pyplot as plt
				from sklearn.cluster import KMeans
				from sklearn.metrics import silhouette_score
				plt.subplot(2,1,1)
				plt.imshow(data[0].reshape(8,8),cmap='gray')
				sil_score = []
				for i in range(5,11):
								km = KMeans(n_clusters=i)
								km.fit(data)
								sil_score.append(silhouette_score(data,km.labels_,metric='euclidean'))
				plt.subplot(2,1,2)
				plt.plot(np.array(range(5,11)),sil_score)
				plt.show()
				return

if __name__=='__main__':
				main()
				

#无返回,只要画出两张图即可,在附件当中附有图片的样子
