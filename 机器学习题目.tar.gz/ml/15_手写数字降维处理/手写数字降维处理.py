#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_digits as dataset
from sklearn.cross_validation import train_test_split 

raw_data = dataset()
data = raw_data.data
label = raw_data.target
xtrain,xtest,ytrain,ytest = train_test_split(data,label,
                                             test_size=0.25,random_state=33)

def main():
    import matplotlib.pyplot as plt
    from sklearn.decomposition import PCA
    from sklearn.svm import LinearSVC
    from sklearn.metrics import f1_score
    #画二维散点图
    pca = PCA(n_components=2)
    dim2_data = pca.fit_transform(data)
    plot_scatter(dim2_data)
    #降维与不降维的对比
    pca1 = PCA(n_components=20)
    svc_raw = LinearSVC() ; svc_20 = LinearSVC()
    #不降维
    svc_raw.fit(xtrain,ytrain)
    pre_raw = svc_raw.predict(xtest)
    var1 = f1_score(pre_raw,ytest,average='micro')
    #降维至20
    xtrain_20 = pca1.fit_transform(xtrain)
    xtest_20 = pca1.transform(xtest)
    svc_20.fit(xtrain_20,ytrain)
    pre_20 = svc_20.predict(xtest_20)
    var2 = f1_score(pre_20,ytest,average='micro')
    return [var1,var2]
def plot_scatter(plot_data):
    import matplotlib.pyplot as plt
    colors = ['black','blue','purple','yellow','green',
              'red','lime','cyan','orange','gray']
    for i in range(10):
        px = plot_data[:,0][label==i]
        py = plot_data[:,1][label==i]
        plt.scatter(px,py,c=colors[i])
    plt.legend(np.arange(0,10).astype(int))
    plt.xlabel('First Principal Component')
    plt.ylabel('Second Principal Component')
    plt.show()

if __name__=='__main__':
    print(main())       
'''
1.要求画一张图,附在压缩文件当中
2.输出结果不固定,但处在一个区间范围内,比如[0.8576598179140593, 0.7718324330101238]
'''
