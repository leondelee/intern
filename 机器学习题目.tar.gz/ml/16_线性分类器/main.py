#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_digits as dataset
from sklearn.cross_validation import train_test_split 

raw_data = dataset()
data = raw_data.data
label = raw_data.target
xtrain,xtest,ytrain,ytest = train_test_split(data,label,
                                             test_size=0.25,random_state=33)

class Solution():
    def predict(self):
        return
    def fit(self,x,y):
        return

if __name__=='__main__':
    sol = Solution()
    sol.fit(xtrain,ytrain)
    print('准确率是: ',sum(sol.predict(xtest)==ytest)/ytest.shape[0])
