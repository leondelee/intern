#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_digits as dataset
from sklearn.cross_validation import train_test_split 

raw_data = dataset()
data = raw_data.data
label = raw_data.target
xtrain,xtest,ytrain,ytest = train_test_split(data,label,
                                             test_size=0.25,random_state=33)

class Solution():
    def __init__(self):
        self.paras = []    #parameters
    def fit(self,x,y):
        x = self.x_process(x)
        y = self.y_process(y)
        Xt = np.transpose(x)
        XtX = np.dot(Xt,x)
        X_cross = np.dot(np.linalg.pinv(XtX),Xt)
        self.paras = np.dot(X_cross,y)
    def y_process(self,y):
        '''
        build a multi-dimension y matrix if it's multi-class
        '''
        y = y.reshape(-1,1)
        num = y.shape[0]
        y_unique = np.unique(y).reshape(1,-1)   # to form a 1*29 numpy array
        classes = np.repeat(y_unique,num,axis=0)
        res_mat = (y==classes).astype(int)
        return res_mat
    def x_process(self,x):
        '''
        add ones
        '''
        train_sample_num = x.shape[0]
        train_attrs_num = x.shape[1]
        x = np.hstack((np.ones((train_sample_num,1)),x))    # add ones
        return x
    def predict(self,xtest):
        xtest = self.x_process(xtest)
        xtest = np.transpose(xtest)
        pre = np.dot(np.transpose(self.paras),xtest) 
        res_pre = np.argmax(pre,axis=0) 
        return res_pre

if __name__=='__main__':
    sol = Solution()
    sol.fit(xtrain,ytrain)
    print('准确率是: ',sum(sol.predict(xtest)==ytest)/ytest.shape[0])
