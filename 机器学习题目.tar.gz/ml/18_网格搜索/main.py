#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_breast_cancer as dataset
from sklearn.cross_validation import train_test_split 

raw_data = dataset()
data = raw_data.data
label = raw_data.target
xtrain,xtest,ytrain,ytest = train_test_split(data,label,
                                             test_size=0.25,random_state=33)

def main():
    var1 = var2 = 0
    return [var1,var2]

if __name__=='__main__':
    print(main())
