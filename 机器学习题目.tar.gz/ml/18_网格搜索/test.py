#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_breast_cancer as dataset
from sklearn.cross_validation import train_test_split 

raw_data = dataset()
data = raw_data.data
label = raw_data.target
xtrain,xtest,ytrain,ytest = train_test_split(data,label,
                                             test_size=0.25,random_state=33)

def main():
    from sklearn.svm import SVC
    from sklearn.metrics import f1_score
    #默认参数
    svc_raw = SVC()
    svc_raw.fit(xtrain,ytrain)
    pre_raw = svc_raw.predict(xtest)
    var1 = f1_score(pre_raw,ytest)
    #最优参数搜索
    from sklearn.grid_search import GridSearchCV
    svc_search = SVC()
    paras = {'gamma':[0,1,2],'C':[1,2,3],'kernel':['linear','sigmoid']}
    gs = GridSearchCV(svc_search,paras,verbose=4,refit=True,cv=3,scoring='f1',n_jobs=4)
    gs.fit(data,label)
    var2 = gs.best_score_
    return [var1,var2]

if __name__=='__main__':
    print(main())
