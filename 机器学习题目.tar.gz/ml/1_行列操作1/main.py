#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris

iris = load_iris()
feature_name = iris.feature_names   #列名
value = iris.data                   #数据

def main():
    res = []
    return res
