#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
xtrain = [[6],[8],[10],[14],[18]]
ytrain = [[7],[9],[13],[17.5],[18]]
def main():
    return

if __name__=='__main__':
    main()
