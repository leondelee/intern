#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
xtrain = [[6],[8],[10],[14],[18]]
ytrain = [[7],[9],[13],[17.5],[18]]
def main():
    import matplotlib.pyplot as plt
    from sklearn.linear_model import LinearRegression
    model1 = LinearRegression()
    model1.fit(xtrain,ytrain)
    #二次拟合
    from sklearn.preprocessing import PolynomialFeatures
    poly2 = PolynomialFeatures(degree=2)
    xtrain_2 = poly2.fit_transform(xtrain)
    model2 = LinearRegression()
    model2.fit(xtrain_2,ytrain)
    #可视化
    xx = np.linspace(0,26,100)
    xx1 = xx.reshape(xx.shape[0],1)
    xx2 = poly2.fit_transform(xx1)
    yy1 = model1.predict(xx1)
    yy2 = model2.predict(xx2)
    plt.scatter(xtrain,ytrain)
    plt.plot(xx,yy1)
    plt.plot(xx,yy2)
    plt.legend(['Degree1','Degree2'])
    plt.show()
    return

if __name__=='__main__':
    main()   #出现一张图,放在压缩文件里
