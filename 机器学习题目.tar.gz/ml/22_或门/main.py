#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
class Solution:
    def main(self,x1,x2):
        return 
if __name__=='__main__':
    sol = Solution()
    print(sol.main(0,1))
    print(sol.main(1,0))
    print(sol.main(0,0))
    print(sol.main(1,1))
