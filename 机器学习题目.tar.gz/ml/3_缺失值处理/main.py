#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
from sklearn.datasets import load_boston as dataset

data = dataset()    
feature_name = data.feature_names    #列名
value = data.data                    #数据

def main():
    res = 0
    return res
