#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.datasets import load_boston as dataset

data = dataset()    
feature_name = data.feature_names   
value = data.data

def step1():
    raw_data = pd.DataFrame(value,columns=feature_name)
    return raw_data
def step2():
    raw_data = step1()
    second_col = raw_data[feature_name[2]]
    second_col_counts = second_col.value_counts()   #数不同数据出现的频率
    index = second_col.value_counts().index         #统计各种数据出现的频率
    maj_times = second_col_counts[index[0]]         #取出现次数最多的频率
    return maj_times
def step3():
    raw_data = step1()
    forth_col = raw_data[feature_name[4]]
    forth_col_sorted = forth_col.sort_values(ascending=False)
    maj_times = step2()
    nan_index = forth_col_sorted.index[0:maj_times]
    forth_col[nan_index] = np.nan
    return raw_data
def step4():
    return step3().dropna(how='any')
def main():
    return step4()[feature_name[1]].mean()

if __name__=='__main__':
				print(main())
