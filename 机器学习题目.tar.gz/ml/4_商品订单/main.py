#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd

def main():
    var1 = var2 = var3 = 0
    return [var1,var2,var3]


