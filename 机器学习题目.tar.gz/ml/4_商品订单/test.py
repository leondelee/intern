#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd

def main():
    url = 'https://raw.githubusercontent.com/justmarkham/DAT8/master/data/chipotle.tsv' 
    chipo = pd.read_csv(url, sep = '\t')
    #去除$符号
    chipo["item_price"] = chipo["item_price"].str.split('$').str[1]
    #将object类型转成number类型，计数
    chipo["item_price"] = pd.to_numeric(chipo["item_price"])
    var1 = (chipo["item_price"]>10).value_counts()[True]
    var2 = chipo.sort_values(by = "item_price", ascending = False).head(1)['quantity'][3598]
    var3 = len(chipo[chipo.item_name == "Veggie Salad Bowl"])
    return [var1,var2,var3]

if __name__=='__main__':
    print(main())      #[1130, 15, 18]
