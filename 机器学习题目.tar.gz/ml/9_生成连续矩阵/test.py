#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
Z = np.array([[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]])
def main(Z):
				n = 3
				i = 1 + (Z.shape[0] - 3)
				j = 1 + (Z.shape[1] - 3)
				C = np.lib.stride_tricks.as_strided(Z, shape=(i, j, n, n), strides=Z.strides + Z.strides)
				return C

if __name__=='__main__':
    print(main(Z))
