#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
class Solution:
    def sigmoid(self,z):
        return 1/(np.exp(-z)+1)
    def main(self,x1,x2):
        para = np.array([[-15],[10],[10]])
        input_layer = np.array([[1],[x1],[x2]])
        a = np.dot(para.T,input_layer)
        return (self.sigmoid(a)>0.5)[0][0].astype(int)
if __name__=='__main__':
    sol = Solution()
    print(sol.main(0,1))
    print(sol.main(1,0))
    print(sol.main(0,0))
    print(sol.main(1,1))
