#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from sklearn.datasets import load_digits as dataset
data = dataset().data
label = dataset().target
test_sample = np.array([[ 0.        , -0.33093388,  1.04367885,  0.99394186,  0.7524843 ,
        -1.00094912, -0.41286929, -0.12082292, -0.06827569,  0.64145743,
         0.67271507, -1.00450955,  1.18102687, -1.1831938 , -0.51273871,
        -0.1206196 , -0.05156009, -0.7270524 , -1.60131763, -0.52653354,
         1.44990848, -1.25994552,  0.07680357, -0.11302329, -0.03856149,
        -0.79199318, -0.99493834,  0.37445099,  0.99971233,  1.43520036,
         2.91882665, -0.03856149,  0.        , -0.68036488,  0.68061739,
         1.11633953,  0.12255218, -0.30790092, -0.27194293,  0.        ,
        -0.06190833, -0.52478368, -0.13647547,  1.34160474, -1.23437675,
        -1.46224308, -0.81438233, -0.091288  , -0.03355742, -0.4062317 ,
        -0.08120604,  1.03134681, -1.77240376, -1.43871685, -0.76699946,
        -0.21052341,  0.        , -0.29488186,  1.29858857, -0.22574999,
        -2.42347337, -1.16041401, -0.51868596, -0.20345521]])

def main():
    from sklearn.cross_validation import train_test_split 
    from sklearn.preprocessing import StandardScaler
    from sklearn.svm import LinearSVC
    #数据集分割
    xtrain,xtest,ytrain,ytest = train_test_split(data,label,test_size=0.25)
    #标准化处理
    ss = StandardScaler()
    xtrain = ss.fit_transform(xtrain)
    xtest = ss.transform(xtest)
    #训练
    lsvc = LinearSVC()
    lsvc.fit(xtrain,ytrain)
    #预测
    pre = lsvc.predict(xtest)
    print('准确率=',sum(pre==ytest)/ytest.shape[0])
    return lsvc   

if __name__=='__main__':
				model = main()
				print(model.predict(test_sample)[0])      #7
