#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
A = np.array([[4, 6, 9, 4, 8, 8, 7, 4, 1, 6],
       [3, 7, 7, 3, 5, 5, 9, 4, 5, 2],
       [7, 9, 8, 8, 4, 6, 8, 5, 5, 1],
       [5, 5, 4, 8, 8, 9, 8, 7, 7, 1],
       [1, 4, 2, 3, 5, 1, 9, 7, 6, 5],
       [6, 1, 7, 5, 1, 8, 4, 5, 3, 5],
       [7, 8, 3, 6, 5, 9, 9, 3, 1, 1],
       [5, 2, 4, 1, 9, 1, 3, 1, 5, 9],
       [9, 2, 6, 6, 7, 6, 5, 8, 4, 1],
       [2, 9, 9, 4, 1, 4, 3, 9, 7, 3]])

def main(p0,p1,c,A):
				shape = [c,c]
				position = [p0,p1]
				R = np.ones(shape, dtype=A.dtype) * 0
				P  = np.array(list(position)).astype(int)
				Rs = np.array(list(R.shape)).astype(int)
				As = np.array(list(A.shape)).astype(int)

				R_start = np.zeros(len(shape)).astype(int)
				R_stop  = np.array(list(shape)).astype(int)
				A_start = (P - Rs // 2)
				A_stop  = (P + Rs // 2) + Rs % 2

				R_start = (R_start - np.minimum(A_start, 0)).tolist()
				A_start = (np.maximum(A_start, 0)).tolist()
				R_stop = np.maximum(R_start, (R_stop - np.maximum(A_stop - As, 0))).tolist()
				A_stop = (np.minimum(A_stop, As)).tolist()

				r = [slice(start,stop) for start, stop in zip(R_start, R_stop)]
				a = [slice(start,stop) for start, stop in zip(A_start, A_stop)]
				R[r] = A[a]
				return R

if __name__=='__main__':
    print(main(2,2,3,A))
				
    
