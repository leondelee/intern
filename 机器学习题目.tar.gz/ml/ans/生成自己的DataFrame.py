#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd
def main():
    data = pd.DataFrame([[1,2,3,4,5],['1','2','3','4','5']],
                    index=['北京','上海'],columns=['1月','2月','3月','4月','5月'])
    data = data.apply(lambda x:x*5)
    data.loc['上海'] = pd.to_numeric(data.loc['上海'])
    return data.loc['上海'].var()

if __name__=='__main__':
    print(main())          #308635802.5
