#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
import sklearn
from sklearn.datasets import load_diabetes as dataset
from sklearn.cross_validation import train_test_split 

raw_data = dataset()
data = raw_data.data
label = raw_data.target
xtrain,xtest,ytrain,ytest = train_test_split(data,label,
                                             test_size=0.25,random_state=33)
class Solution:
    def __init__(self, eta=0.1, n_iter=1000):
        self.eta = eta
        self.n_iter = n_iter

    def fit(self, X, y):
        X = np.insert(X, 0, 1, axis=1)
        self.w = np.ones(X.shape[1])
        m = X.shape[0]

        for _ in range(self.n_iter):
            output = X.dot(self.w)
            errors = y - output
            self.w += self.eta / m * errors.dot(X)
        return self

    def predict(self, X):
        return np.insert(X, 0, 1, axis=1).dot(self.w)

    def score(self, X, y):
        return 1 - sum((self.predict(X) - y)**2) / sum((y - np.mean(y))**2)

if __name__=='__main__':
    sol = Solution()
    sol.fit(xtrain,ytrain)
    pre = sol.predict(xtest)
    print('r2-score是: ',sklearn.metrics.r2_score(ytest,pre))
