#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris

iris = load_iris()
feature_name = iris.feature_names   #列名
value = iris.data                   #数据

def main():
    raw_data = pd.DataFrame(value,columns=feature_name)
    res = list(raw_data.var().sort_values(ascending=False).index) 
    useful_names = [res[i] for i in range(2)]
    res = raw_data[useful_names] #方差前2的列名
    res = res.sort_values(by=useful_names[0],ascending=False).reset_index(drop=True)
    return [useful_names[0],useful_names[1],res[useful_names[0]][10],res[useful_names[1]][10]]
