#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris

iris = load_iris()      
feature_name = iris.feature_names   #列名
value = iris.data    #数据

def main():
    raw_data = pd.DataFrame(value,columns=feature_name)
    res = raw_data 
    first_col = raw_data[feature_name[1]]
    fir_mean = first_col.mean()
    fir_std = first_col.std()
    first_col = (first_col-fir_mean)/fir_std
    res['new_feature'] = first_col
    res = res.append(res.agg(['mean','max','min','var']))
    return sum(sum(res.tail(5).values))

if __name__=='__main__':
    print(main())
